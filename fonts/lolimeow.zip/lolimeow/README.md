# 欢迎使用 Lolimeow Wordpress主题

**Lolimeow5.0 更新增加侧栏和无侧栏切换，调整UI**

也不知道说明什么，喜欢就用！！

主要功能：该有的都有！！
会员中心：有 （需要配合erphpdown插件使用，达到收费下载插件，会员中心功能都完整实现）

具体查看博客文章了解详细 [点击查看](https://www.boxmoe.com/468.html "点击查看")

